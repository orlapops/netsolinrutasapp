export interface ItemFact { cod_ref: string; 
    nombre: string;
    cantidad: number;
    precio: number;
    por_iva: number;
    total: number;    
}
