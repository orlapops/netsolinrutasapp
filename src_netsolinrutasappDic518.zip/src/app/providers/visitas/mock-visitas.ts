export let VISITAS = [
  {
    id: 1,
    cod_tercer: "830099553",
    direccion: "calle sdkjdfjkfd df df",
    estado: "P",
    nombre: "Nombre cliente 1",
    notaing: "Nota cliente",
    fecha_prog: "2018-10-30",
    hora_prog: "10:20",
    location: {
      lat: -22.906847,
      lon: -43.172896,
    },
    thumb: "assets/img/hotel/thumb/hotel_1.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_1.jpg",
      "assets/img/hotel/thumb/hotel_4.jpg",
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_6.jpg"
    ],
  },
  {
    id: 2,
    cod_tercer: "83009955sd",
    direccion: "calle sdsdkjdfjkfd df df",
    estado: "P",
    nombre:"Nombre cliente 2",
    notaing:"Nota cliente 2",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -22.969778,
      lon: -43.186859,
    },
    thumb: "assets/img/hotel/thumb/hotel_2.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_2.jpg",
      "assets/img/hotel/thumb/hotel_4.jpg",
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_6.jpg"
    ],
   },
  {
    id: 3,
    cod_tercer: "83009955sd3",
    direccion: "calle sdsdkjdfjkfd df df 3",
    estado: "P",
    nombre:"Nombre cliente 3",
    notaing:"Nota cliente 3",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -22.984337,
      lon: -43.223142,
    },
    thumb: "assets/img/hotel/thumb/hotel_3.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_3.jpg",
      "assets/img/hotel/thumb/hotel_4.jpg",
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_6.jpg"
    ],
   },
  {
    id: 4,
    cod_tercer: "83009955sd4",
    direccion: "calle sdsdkjdfjkfd df df 4",
    estado: "P",
    nombre:"Nombre cliente 4",
    notaing:"Nota cliente 4",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -22.933129,
      lon: -43.177427,
    },
    thumb: "assets/img/hotel/thumb/hotel_4.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_4.jpg",
      "assets/img/hotel/thumb/hotel_7.jpg",
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_6.jpg"
    ],
  },
  {
    id: 5,
    cod_tercer: "83009955sd5",
    direccion: "calle sdsdkjdfjkfd df df 5",
    estado: "P",
    nombre:"Nombre cliente 5",
    notaing:"Nota cliente 5",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -22.984667,
      lon: -43.198593,
    },
    thumb: "assets/img/hotel/thumb/hotel_5.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_8.jpg",
      "assets/img/hotel/thumb/hotel_7.jpg",
      "assets/img/hotel/thumb/hotel_6.jpg"
    ],
   },
  {
    id: 6,
    cod_tercer: "83009955sd6",
    direccion: "calle sdsdkjdfjkfd df df 6",
    estado: "P",
    nombre:"Nombre cliente 6",
    notaing:"Nota cliente 6",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -23.000371,
      lon: -43.365895,
    },
    thumb: "assets/img/hotel/thumb/hotel_6.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_6.jpg",
      "assets/img/hotel/thumb/hotel_4.jpg",
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_10.jpg"
    ],
    },
  {
    id: 7,
    cod_tercer: "83009955sd7",
    direccion: "calle sdsdkjdfjkfd df df 7",
    estado: "P",
    nombre:"Nombre cliente 7",
    notaing:"Nota cliente 7",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -23.791402,
      lon: -45.567807,
    },
    thumb: "assets/img/hotel/thumb/hotel_7.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_7.jpg",
      "assets/img/hotel/thumb/hotel_8.jpg",
      "assets/img/hotel/thumb/hotel_10.jpg",
      "assets/img/hotel/thumb/hotel_9.jpg"
    ],
  },
  {
    id: 8,
    cod_tercer: "83009955sd8",
    direccion: "calle sdsdkjdfjkfd df df 8",
    estado: "P",
    nombre:"Nombre cliente 8",
    notaing:"Nota cliente 8",
    fecha_prog: "2018-10-28",
    hora_prog: "11:20",
    location: {
      lat: -9.010380,
      lon: -35.220805,
    },
    thumb: "assets/img/hotel/thumb/hotel_8.jpg",
    images: [
      "assets/img/hotel/thumb/hotel_8.jpg",
      "assets/img/hotel/thumb/hotel_9.jpg",
      "assets/img/hotel/thumb/hotel_5.jpg",
      "assets/img/hotel/thumb/hotel_6.jpg"
    ],
  }
]
