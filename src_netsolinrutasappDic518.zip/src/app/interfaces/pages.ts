export interface Pages {
    title: string,
    url: any,
    direct?: string,
    icon?: string
}

